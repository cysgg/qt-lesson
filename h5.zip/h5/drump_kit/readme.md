- vh viewheight 等比例的高度
    100 满高度

- flex 弹性布局，重要的布局方式，
    可以在弹性空间放置，特别适合手机等移动世界

    子元素，都是div，块级元素，天生换行，flex会改变这个

- 盒子模型
    了解元素在页面上的表现
    盒子模型 = 内容(w/h) + 内间距(padding) + 边框(border) + 外间距(margin) + position

- rem 根据html的字体大小来等比例 10px