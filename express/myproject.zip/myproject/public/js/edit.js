(function () {
  
})(window)