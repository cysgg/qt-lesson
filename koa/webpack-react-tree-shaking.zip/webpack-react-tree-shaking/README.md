## tree-shaking
- 依赖 ES6 import export (在js编译的时候就能分析哪些模块用到了)
- 别人的包用的可能是 commonJS